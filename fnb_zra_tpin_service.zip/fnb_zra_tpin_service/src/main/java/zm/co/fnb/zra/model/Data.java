package zm.co.fnb.zra.model;

import org.springframework.stereotype.Component;

@Component
public class Data {

	private String tokenType;
	private String sessionState;
	private String accesstoken;
	private String expresin;
	private String refreshToken;
	private String refreshExpiresIn;
	private String idToken;
	
	
	
	public Data() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Data(String tokenType, String sessionState, String accesstoken, String expresin, String refreshToken,
			String refreshExpiresIn, String idToken) {
		super();
		this.tokenType = tokenType;
		this.sessionState = sessionState;
		this.accesstoken = accesstoken;
		this.expresin = expresin;
		this.refreshToken = refreshToken;
		this.refreshExpiresIn = refreshExpiresIn;
		this.idToken = idToken;
	}



	public String getTokenType() {
		return tokenType;
	}



	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}



	public String getSessionState() {
		return sessionState;
	}



	public void setSessionState(String sessionState) {
		this.sessionState = sessionState;
	}



	public String getAccesstoken() {
		return accesstoken;
	}



	public void setAccesstoken(String accesstoken) {
		this.accesstoken = accesstoken;
	}



	public String getExpresin() {
		return expresin;
	}



	public void setExpresin(String expresin) {
		this.expresin = expresin;
	}



	public String getRefreshToken() {
		return refreshToken;
	}



	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}



	public String getRefreshExpiresIn() {
		return refreshExpiresIn;
	}



	public void setRefreshExpiresIn(String refreshExpiresIn) {
		this.refreshExpiresIn = refreshExpiresIn;
	}



	public String getIdToken() {
		return idToken;
	}



	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}



	@Override
	public String toString() {
		return "Data [tokenType=" + tokenType + ", sessionState=" + sessionState + ", accesstoken=" + accesstoken
				+ ", expresin=" + expresin + ", refreshToken=" + refreshToken + ", refreshExpiresIn=" + refreshExpiresIn
				+ ", idToken=" + idToken + "]";
	}

}
