package zm.co.fnb.zra.model;

import org.springframework.stereotype.Component;

@Component
public class Debtor {

	private String institution;
	private String account_number;
	private String transaction_type;
	
	public Debtor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getAccount_number() {
		return account_number;
	}

	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	
}
