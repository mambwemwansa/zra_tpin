package zm.co.fnb.zra.model;


public class LoginResponse {
	
	Header header;
	Data data;

	public LoginResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginResponse(Header header, Data data) {
		super();
		this.header = header;
		this.data = data;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "LoginResponse [header=" + header + ", data=" + data + "]";
	}

		
}
