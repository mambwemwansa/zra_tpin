package zm.co.fnb.zra.model;

public class LookUpResponse {
	

	LookUPHeader header;
	LookUpData data;
	
	public LookUpResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LookUpResponse(LookUPHeader header, LookUpData data) {
		super();
		this.header = header;
		this.data = data;
	}
	public LookUPHeader getHeader() {
		return header;
	}
	public void setHeader(LookUPHeader header) {
		this.header = header;
	}
	public LookUpData getData() {
		return data;
	}
	public void setData(LookUpData data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "LookUpResponse [header=" + header + ", data=" + data + "]";
	}
	
	
}
